const express = require('express');
const Application = require('../models/Application');
const router = express.Router();

router.post('/:jobId/apply', async (req, res) => {
  const application = new Application({ jobId: req.params.jobId, ...req.body });
  await application.save();
  res.status(201).json(application);
});

router.get('/', async (req, res) => {
  const applications = await Application.find().populate('jobId');
  res.json(applications);
});

router.delete('/:id', async (req, res) => {
  await Application.findByIdAndDelete(req.params.id);
  res.json({ message: 'Application deleted' });
});

module.exports = router;