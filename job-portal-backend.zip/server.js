const express = require('express');
const mongoose = require('./config/db');
const jobRoutes = require('./routes/jobs');
const applicationRoutes = require('./routes/applications');
require('dotenv').config();

const app = express();
app.use(express.json());

app.use('/jobs', jobRoutes);
app.use('/applications', applicationRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));